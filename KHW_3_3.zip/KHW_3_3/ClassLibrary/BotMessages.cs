using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace ClassLibrary
{
    /// <summary>
    /// Класс, выводящий сообщения пользователю.
    /// </summary>
    public class BotMessages
    {
        /// <summary>
        /// Выводит базовую информацию.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public static async Task SendBaseInfo(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            Message message = await botClient.SendTextMessageAsync(
                chatId: update.Message.Chat.Id,
                text: "Это бот, который фильтрует и сортирует .csv или .json файлы по определённым полям",
                cancellationToken: cancellationToken);
        }


        /// <summary>
        /// Выводит заданную информацию.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="text"></param>
        /// <returns></returns>
        public static async Task SendMessage(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, string text)
        {
            Message message = await botClient.SendTextMessageAsync(
                chatId: update.Message.Chat.Id,
                text: text,
                cancellationToken: cancellationToken);
        }


        /// <summary>
        /// Выводит кнопки.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="replyKeyboardMarkup"></param>
        /// <returns></returns>
        public static async Task SendMenyByttons(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, ReplyKeyboardMarkup replyKeyboardMarkup)
        {
            Message sentMessage = await botClient.SendTextMessageAsync(
               chatId: update.Message.Chat.Id,
               text: "Начало работы с ботом.\nВыберите один из пунктов на кнопках",
               
               replyMarkup: replyKeyboardMarkup,
               cancellationToken: cancellationToken);
            Message PatrickBatemanWalking = await botClient.SendStickerAsync(
                chatId:update.Message.Chat.Id, 
                new InputFileId("CAACAgIAAxkBAAEENhZl_H4icY075vXLCxT790jV--YSZQACCBYAAnoOOEgjOv-ctXaamjQE"),
                cancellationToken: cancellationToken);
        }
    }
}
