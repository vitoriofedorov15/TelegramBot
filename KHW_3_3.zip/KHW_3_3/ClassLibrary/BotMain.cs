﻿using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace ClassLibrary
{
    /// <summary>
    /// Основной класс запуска бота.
    /// </summary>
    public class BotMain
    {
        // Список кнопок.
        static ReplyKeyboardMarkup replyKeyboardMarkup = new(new[] {
                new KeyboardButton[] { "Загрузка csv", "Выгрузка csv" },
                new KeyboardButton[] { "Загрузка json", "Выгрузка json" },
                new KeyboardButton[] { "Сортировка в прямом порядке", "Сортировка в обратном порядке" },
                new KeyboardButton[] { "Фильтрация по SecurityStatus", "Фильтрация по ObjectType" },
                new KeyboardButton[] { "Фильтрация по SecurityStatus и Category" },
                new KeyboardButton[] { "Вывести информацию о боте" }
            })
        { ResizeKeyboard = true, IsPersistent = true };
        // Экземпляр класса с методами обработки.
        Dictionary<long, BotMethods> botMethodsForChats = new() { };


        /// <summary>
        /// Запуск бота.
        /// </summary>
        /// <returns></returns>
        public async Task Start()
        {
            var botClient = new TelegramBotClient("6677847303:AAHuhzUXeauNcVSqgXCprxZPjtD6zG9kiy0");
            using CancellationTokenSource cts = new();
            // StartReceiving does not block the caller thread. Receiving is done on the ThreadPool.
            ReceiverOptions receiverOptions = new()
            {
                // receive all update types except ChatMember related updates
                AllowedUpdates = Array.Empty<UpdateType>()
            };
            botClient.StartReceiving(
                updateHandler: HandleUpdateAsync,
                pollingErrorHandler: HandlePollingErrorAsync,
                receiverOptions: receiverOptions,
                cancellationToken: cts.Token
            );
            var me = await botClient.GetMeAsync();
            Console.WriteLine($"Start listening for @{me.Username}");
            Console.ReadLine();
            // Send cancellation request to stop bot
            cts.Cancel();
        }


        /// <summary>
        /// Обрабатывает апдейты бота.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            // Обрабатываем только сообщения.
            if (update.Type == UpdateType.Message)
            {
                var message = update.Message;
                long chatId = message.Chat.Id;
                // Для новых пользователей создает свой объект класса для обработки.
                if (!botMethodsForChats.ContainsKey(chatId)) { botMethodsForChats.Add(chatId, new BotMethods(replyKeyboardMarkup)); }
                switch (message.Type)
                {
                    // Текстовое.
                    case MessageType.Text:
                        await botMethodsForChats[chatId].TextProcessing(botClient, update, cancellationToken);
                        break;
                    // Файл.
                    case MessageType.Document:
                        await botMethodsForChats[chatId].DocumentProcessing(botClient, update, cancellationToken);
                        break;
                    // Другие не предполагаются => введены некорретные данные => отправить пользователю подсказку.
                    default:
                        await BotMessages.SendBaseInfo(botClient, update, cancellationToken);
                        await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
                        break;
                }
            }
        }


        Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            var ErrorMessage = exception switch
            {
                ApiRequestException apiRequestException
                    => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
                _ => exception.ToString()
            };

            Console.WriteLine(ErrorMessage);
            return Task.CompletedTask;
        }
    }
}

