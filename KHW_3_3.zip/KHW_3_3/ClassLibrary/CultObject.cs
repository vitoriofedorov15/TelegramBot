using System.Text.Json.Serialization;

namespace ClassLibrary
{
    /// <summary>
    /// Класс объектов, с которыми работаем.
    /// </summary>
    [Serializable]
    public class CultObject
    {
        // Свойства.
        [JsonPropertyName("AISID")]
        public string Aisid { get; set; }
        [JsonPropertyName("USRCHONumber")]
        public string UsrchoNumber { get; set; }
        [JsonPropertyName("ObjectNameOnDoc")]
        public string ObjectNameOnDoc { get; set; }
        [JsonPropertyName("EnsembleNameOnDoc")]
        public string EnsembleNameOnDoc { get; set; }
        [JsonPropertyName("SecurityStatus")]
        public string SecurityStatus { get; set; }
        [JsonPropertyName("Category")]
        public string Category { get; set; }
        [JsonPropertyName("ObjectType")]
        public string ObjectType { get; set; }
        [JsonPropertyName("global_id")]
        public string GlobalId { get; set; }


        [JsonConstructor]
        // Конструкторы.
        public CultObject(string aisid, string usrchoNumber, string objectNameOnDoc, string ensembleNameOnDoc, string securityStatus, string category, string objectType, string globalId)
        {
            Aisid = aisid;
            UsrchoNumber = usrchoNumber;
            ObjectNameOnDoc = objectNameOnDoc;
            EnsembleNameOnDoc = ensembleNameOnDoc;
            SecurityStatus = securityStatus;
            Category = category;
            ObjectType = objectType;
            GlobalId = globalId;
        }
        public CultObject() : this("", "", "", "", "", "", "", "") { }


        /// <summary>
        /// Представление объекта в формате csv.
        /// </summary>
        /// <returns></returns>
        public string ToCsv()
        {
            return $"\"{Aisid}\";\"{UsrchoNumber}\";\"{ObjectNameOnDoc}\";\"{EnsembleNameOnDoc}\";\"{SecurityStatus}\";\"{Category}\";\"{ObjectType}\";\"{GlobalId}\";";
        }


        /// <summary>
        /// Представление объекта в виде строки.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return $"Aisid = {Aisid}; UsrchoNumber = {UsrchoNumber}; ObjectNameOnDoc={ObjectNameOnDoc}; EnsembleNameOnDoc = {EnsembleNameOnDoc}; " +
                $"SecurityStatus = {SecurityStatus}; Category = {Category}; ObjectType = {ObjectType}; GlobalId = {GlobalId}";
        }
    }
}