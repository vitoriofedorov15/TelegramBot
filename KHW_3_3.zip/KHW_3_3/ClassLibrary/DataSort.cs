namespace ClassLibrary
{
    /// <summary>
    /// Класс для сортировки данных.
    /// </summary>
    public class DataSort
    {
        /// <summary>
        /// Сортирует в прямом порядке.
        /// </summary>
        /// <param name="cultObjects"></param>
        public static void SortAscending(ref List<CultObject> cultObjects)
        {
            cultObjects = (from values in cultObjects
                orderby values.ObjectNameOnDoc ascending
                select values).ToList();
        }


        /// <summary>
        /// Сортирует в обратном порядке.
        /// </summary>
        /// <param name="cultObjects"></param>
        public static void SortDescending(ref List<CultObject> cultObjects)
        {
            cultObjects = (from values in cultObjects
                orderby values.ObjectNameOnDoc descending
                select values).ToList();
        }
    }
}