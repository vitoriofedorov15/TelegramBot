using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.ReplyMarkups;

namespace ClassLibrary
{
    /// <summary>
    /// Содержит методы для логики работы бота.
    /// </summary>
    public class BotMethods
    {
        // Массив обрабатываемых объектов.
        List<CultObject> cultObjects = new() { };
        // Действие, выполняемое ботом.
        BotWays nowAction = BotWays.baseInfo;
        // Возможные значения для фильтрации.
        List<string> valuesForFiltr = new() { };
        // Кнопки.
        ReplyKeyboardMarkup replyKeyboardMarkup;


        /// <summary>
        /// Конструктор, требует список кнопок.
        /// </summary>
        /// <param name="replyKeyboardMarkup"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public BotMethods(ReplyKeyboardMarkup replyKeyboardMarkup)
        {
            if (replyKeyboardMarkup is null) { throw new ArgumentNullException(); }
            this.replyKeyboardMarkup = replyKeyboardMarkup;
        }


        // Безпараметрический.
        public BotMethods() { }


        /// <summary>
        /// Считывает загруженный в бот файл.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="fileName"></param>
        /// <param name="read"></param>
        /// <returns></returns>
        public async Task DownloadFileForRead(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, string fileName, Func<Stream, List<CultObject>> read)
        {
            var fileId = update.Message.Document.FileId;
            var fileInfo = await botClient.GetFileAsync(fileId);
            var filePath = fileInfo.FilePath;
            // Куда сохранится на компьютере.
            string destinationFilePath = fileName;
            await using (Stream fileStream = System.IO.File.Create(destinationFilePath))
            {
                await botClient.DownloadFileAsync(
                    filePath: filePath,
                    destination: fileStream,
                    cancellationToken: cancellationToken);
                // Если не выскочило ошибок => файл корректен.
                try { cultObjects = read(fileStream); }
                // Схватили исключение => файл с некорректным содержимым.
                catch (ArgumentOutOfRangeException) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Подан файл с некорректным содержимым"); return; }
                await BotMessages.SendMessage(botClient, update, cancellationToken, "Файл успешно считан");
                await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
            }
        }


        /// <summary>
        /// Выгружает обработанный файл в бот.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="fileName"></param>
        /// <param name="write"></param>
        /// <returns></returns>
        private async Task UploadFileWrite(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, string fileName, Func<List<CultObject>, Stream> write)
        {
            using (Stream stream = write(cultObjects))
            {
                Message message = await botClient.SendDocumentAsync(
                chatId: update.Message.Chat.Id,
                document: InputFile.FromStream(stream: stream, fileName: fileName),
                caption: "Обработанный файл");
                
                Message PatrickBatemanSigmaFace = await botClient.SendStickerAsync(
                    chatId:update.Message.Chat.Id, 
                    new InputFileId("CAACAgIAAxkBAAEENhpl_H4xyShr3SNADeTjSAUi1dJG2AACwhUAAlAdSUhTlP1Qw1XqODQE"),
                    cancellationToken: cancellationToken);
            }
            await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
        }


        /// <summary>
        /// Занимается обработкой текстовых сообзений.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task TextProcessing(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            string valuesForPrint;
            Message message = update.Message;
            switch (message.Text)
            {
                // Файлы.
                case "Загрузка csv":
                    await BotMessages.SendMessage(botClient, update, cancellationToken, "Загрузите csv-файл для считывания");
                    // Переключение на нужное действие.
                    nowAction = BotWays.downloadCsv;
                    break;
                case "Выгрузка csv":
                    nowAction = BotWays.uploadCsv;
                    // Если список объектов пуст => не было файла для считывания т.к после считывания и обработок не может быть пуст.
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else { await UploadFileWrite(botClient, update, cancellationToken, "result.csv", CSVProcessing.Write); }
                    nowAction = BotWays.baseInfo;
                    break;
                case "Загрузка json":
                    await BotMessages.SendMessage(botClient, update, cancellationToken, "Загрузите json-файл для считывания");
                    nowAction = BotWays.downloadJson;
                    break;
                case "Выгрузка json":
                    nowAction = BotWays.uploadJson;
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else { await UploadFileWrite(botClient, update, cancellationToken, "result.json", JSONProcessing.Write); }
                    nowAction = BotWays.baseInfo;
                    break;
                // Сортировка.
                case "Сортировка в прямом порядке":
                    nowAction = BotWays.sortAscendingObjectNameOnDoc;
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else
                    { DataSort.SortAscending(ref cultObjects); await AfterSort(botClient, update, cancellationToken); }
                    nowAction = BotWays.baseInfo;
                    break;
                case "Сортировка в обратном порядке":
                    nowAction = BotWays.sortDescendingObjectNameOnDoc;
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else
                    { DataSort.SortDescending(ref cultObjects); await AfterSort(botClient, update, cancellationToken); }
                    nowAction = BotWays.baseInfo;
                    break;
                // Фильтрация.
                case "Фильтрация по SecurityStatus":
                    nowAction = BotWays.filterSecurityStatus;
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else
                    {
                        (valuesForFiltr, valuesForPrint) = DataFiltr.PrintFilter(botClient, update, cancellationToken, ref cultObjects, "SecurityStatus");
                        // Вывод возможных полей сортировки.
                        await BotMessages.SendMessage(botClient, update, cancellationToken, valuesForPrint);
                    }
                    break;
                case "Фильтрация по ObjectType":
                    nowAction = BotWays.filterObjectType;
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else
                    {
                        (valuesForFiltr, valuesForPrint) = DataFiltr.PrintFilter(botClient, update, cancellationToken, ref cultObjects, "ObjectType");
                        await BotMessages.SendMessage(botClient, update, cancellationToken, valuesForPrint);
                    }
                    break;
                case "Фильтрация по SecurityStatus и Category":
                    nowAction = BotWays.filterSecurityStatusAndCategory;
                    if (cultObjects.Count == 0) { await BotMessages.SendMessage(botClient, update, cancellationToken, "Не было подано файла для считывания"); }
                    else
                    {
                        (valuesForFiltr, valuesForPrint) = DataFiltr.PrintFilter(botClient, update, cancellationToken, ref cultObjects, "SecurityStatus and Category");
                        await BotMessages.SendMessage(botClient, update, cancellationToken, valuesForPrint);
                    }
                    break;
                // Общая информация.
                case "Вывести информацию о боте":
                    nowAction = BotWays.baseInfo;
                    await BotMessages.SendBaseInfo(botClient, update, cancellationToken);
                    await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
                    break;
                // Показ кнопок.
                case "/start":
                    await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
                    break;
                default:
                    await DefaultTextProcessing(botClient, update, cancellationToken, message);
                    break;
            }
        }


        /// <summary>
        /// Обработка текстовых сообщений не из меню.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task DefaultTextProcessing(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, Message message)
        {
            // Если занимаемся фильтрацией и введенное значение является одним из возможных - проводим фильтрацию.
            if (nowAction == BotWays.filterSecurityStatus && valuesForFiltr.Contains(message.Text))
            {
                DataFiltr.MakeSecurityFiltr(ref cultObjects, message.Text);
                await AfterFiltr(botClient, update, cancellationToken);
            }
            else if (nowAction == BotWays.filterObjectType && valuesForFiltr.Contains(message.Text))
            {
                DataFiltr.MakeObjectTypeFiltr(ref cultObjects, message.Text);
                await AfterFiltr(botClient, update, cancellationToken);
            }
            else if (nowAction == BotWays.filterSecurityStatusAndCategory && valuesForFiltr.Contains(message.Text))
            {
                DataFiltr.MakeTogetherFiltr(ref cultObjects, message.Text);
                await AfterFiltr(botClient, update, cancellationToken);
            }
            // Если занимаемся фильтрацией, но ввели некорректную строку - уведомляем.
            else if (nowAction == BotWays.filterSecurityStatus || nowAction == BotWays.filterObjectType || nowAction == BotWays.filterSecurityStatusAndCategory)
            {
                await BotMessages.SendMessage(botClient, update, cancellationToken, "Вы ввели некорректные данные для фильтрации, введите еще раз");
            }
            // Некорректные сообщения => отправляем базовую информацию.
            else
            {
                await BotMessages.SendBaseInfo(botClient, update, cancellationToken);
                await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
            }
        }


        /// <summary>
        /// Выводит сообщения после сортировки.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        private async Task AfterSort(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            nowAction = BotWays.baseInfo;
            await BotMessages.SendMessage(botClient, update, cancellationToken, "Сортировка успешно проведена");
            await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
        }


        /// <summary>
        /// Выводит сообщения после фильтрации и чистит список значений.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        private async Task AfterFiltr(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            nowAction = BotWays.baseInfo;
            // Фильтрация проведена => надо зачистить.
            valuesForFiltr.Clear();
            await BotMessages.SendMessage(botClient, update, cancellationToken, "Фильтрация успешно проведена");
            await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
        }


        /// <summary>
        /// Обработка файлов.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public async Task DocumentProcessing(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            switch (nowAction)
            {
                case BotWays.downloadCsv:
                    await DownloadFileForRead(botClient, update, cancellationToken, "downloaded.csv", CSVProcessing.Read);
                    nowAction = BotWays.baseInfo;
                    break;
                case BotWays.downloadJson:
                    await DownloadFileForRead(botClient, update, cancellationToken, "downloaded.csv", JSONProcessing.Read);
                    nowAction = BotWays.baseInfo;
                    break;
                default:
                    await BotMessages.SendBaseInfo(botClient, update, cancellationToken);
                    await BotMessages.SendMenyByttons(botClient, update, cancellationToken, replyKeyboardMarkup);
                    break;
            }
        }
    }
}
