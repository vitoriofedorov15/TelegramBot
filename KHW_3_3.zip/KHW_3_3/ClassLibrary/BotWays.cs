namespace ClassLibrary
{
    /// <summary>
    /// Перечислпние с вариантами состояний работы бота.
    /// </summary>
    public enum BotWays
    {
        baseInfo,
        downloadCsv,
        uploadCsv,
        downloadJson,
        uploadJson,
        filterSecurityStatus,
        filterObjectType,
        filterSecurityStatusAndCategory,
        sortAscendingObjectNameOnDoc,
        sortDescendingObjectNameOnDoc
    }
}