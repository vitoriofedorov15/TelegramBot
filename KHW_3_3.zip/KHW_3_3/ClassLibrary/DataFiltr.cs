using Telegram.Bot;
using Telegram.Bot.Types;

namespace ClassLibrary
{
    /// <summary>
    /// Класс для фильтрации данных.
    /// </summary>
    public class DataFiltr
    {
        /// <summary>
        /// Ищет возможные значения для ыильтрации в зависимости от поля.
        /// </summary>
        /// <param name="cultObjects"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        private static List<string> FindValuesForFiltr(ref List<CultObject> cultObjects, string field)
        {
            List<string> res = new() { };
            switch (field)
            {
                case "SecurityStatus":
                    res = (from values in cultObjects
                           select values.SecurityStatus).Distinct().ToList();
                    break;
                case "ObjectType":
                    res = (from values in cultObjects
                           select values.ObjectType).Distinct().ToList();
                    break;
                case "SecurityStatus and Category":
                    res = (from values in cultObjects
                           select $"{values.SecurityStatus} + {values.Category}").Distinct().ToList();
                    break;
            }
            return res;
        }


        /// <summary>
        /// Вовзращает значения для фильтрации и их представление пользователю.
        /// </summary>
        /// <param name="botClient"></param>
        /// <param name="update"></param>
        /// <param name="cancellationToken"></param>
        /// <param name="cultObjects"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public static (List<string>, string) PrintFilter(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, ref List<CultObject> cultObjects, string field)
        {
            List<string> valuesForFiltr = FindValuesForFiltr(ref cultObjects, field);
            string valuesForPrint = "Выберите значение для фильтрации и напишите его? в формате представленном ниже\n" + String.Join("\n\n", valuesForFiltr);
            return (valuesForFiltr, valuesForPrint);
        }


        /// <summary>
        /// Фильтрация по полю SecyrityStatus.
        /// </summary>
        /// <param name="cultObjects"></param>
        /// <param name="value"></param>
        public static void MakeSecurityFiltr(ref List<CultObject> cultObjects, string value)
        {
            cultObjects = (from values in cultObjects
                           where values.SecurityStatus == value
                           select values).ToList();
        }


        /// <summary>
        /// Фильтрация по полю ObjectType.
        /// </summary>
        /// <param name="cultObjects"></param>
        /// <param name="value"></param>
        public static void MakeObjectTypeFiltr(ref List<CultObject> cultObjects, string value)
        {
            cultObjects = (from values in cultObjects
                           where values.ObjectType == value
                           select values).ToList();
        }


        /// <summary>
        /// Фильтрация по полям SecurityStatus и Category.
        /// </summary>
        /// <param name="cultObjects"></param>
        /// <param name="value"></param>
        public static void MakeTogetherFiltr(ref List<CultObject> cultObjects, string value)
        {
            cultObjects = (from values in cultObjects
                           where $"{values.SecurityStatus} + {values.Category}" == value
                           select values).ToList();
        }
    }
}
