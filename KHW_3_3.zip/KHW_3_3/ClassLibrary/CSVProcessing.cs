using System.Text;

namespace ClassLibrary
{
    /// <summary>
    /// Считывание и запись CSV-файла.
    /// </summary>
    public class CSVProcessing
    {
        // Вид первых двух строк для соответствия формата.
        static string goodFirstLine = "\"AISID\";\"USRCHONumber\";\"ObjectNameOnDoc\";\"EnsembleNameOnDoc\";\"SecurityStatus\";\"Category\";\"ObjectType\";\"global_id\";";
        static string goodSecondLine = "\"Идентификатор в АИС Мосгорнаследия\";\"Номер ЕГРОКН\";\"Наименование объекта по документам\";" +
            "\"Наименование ансамбля по документам\";\"Охранный статус\";\"Категория объекта\";\"Вид объекта недвижимости\";\"global_id\";";


        /// <summary>
        /// Считывает csv-файл.
        /// </summary>
        /// <param name="stream"></param>
        /// <returns>Список объектов обрабатываемого типа.</returns>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public static List<CultObject> Read(Stream stream)
        {
            // Итоговый список.
            List<CultObject> result = new() { };
            int lineNumber = 0;
            string line;
            // Установка в начало файла.
            stream.Seek(0, SeekOrigin.Begin);
            using (StreamReader sr = new StreamReader(stream))
            {
                while (!((line = sr.ReadLine()) is null))
                {
                    try
                    {
                        // Первые две строки не удовлетворяют формату.
                        if (lineNumber == 0 && line != goodFirstLine) { throw new ArgumentOutOfRangeException(); }
                        if (lineNumber == 1 && line != goodSecondLine) { throw new ArgumentOutOfRangeException(); }
                        List<string> insideLine = line.Split("\";\"").ToList();
                        insideLine[0] = insideLine[0].TrimStart('\"');
                        insideLine[7] = insideLine[7].TrimEnd(';').TrimEnd('\"');
                        // Если первые 2 строки -  ничего не сохраняем.
                        if (lineNumber == 0 || lineNumber == 1) { lineNumber += 1; }
                        // Проверка на то, что стоят числовые значения, достаточное количество полей.
                        else if (insideLine.Count != 8 || (insideLine[1].Length != 0 && !long.TryParse(insideLine[1], out _)) ||
                            (insideLine[1].Length != 0 && !long.TryParse(insideLine[7].TrimEnd('\"'), out _))) { throw new ArgumentOutOfRangeException(); }
                        else
                        {
                            // Все корректно => создаем и добавляем объект.
                            CultObject cultObject = new CultObject(insideLine[0].TrimStart('\"'), insideLine[1], insideLine[2], insideLine[3],
                                insideLine[4], insideLine[5], insideLine[6], insideLine[7]);
                            result.Add(cultObject);
                            lineNumber += 1;
                        }
                    }
                    // Бросилось какое-либо из исключений => некорректный формат.
                    catch (ArgumentOutOfRangeException) { throw new ArgumentOutOfRangeException(); }
                    catch (ArgumentNullException) { throw new ArgumentOutOfRangeException(); }
                    catch (Exception) { throw new ArgumentOutOfRangeException(); }
                }
                // Всего 2 строки => нет данных.
                if (lineNumber <= 2) { throw new ArgumentOutOfRangeException(); }
                return result;
            }
        }


        /// <summary>
        /// Записывает данные в файл и создает поток.
        /// </summary>
        /// <param name="cultObjects"></param>
        /// <returns></returns>
        public static Stream Write(List<CultObject> cultObjects)
        {
            // Запись.
            StringBuilder sb = new StringBuilder();
            sb.Append(goodFirstLine + '\n');
            sb.Append(goodSecondLine + '\n');
            foreach (var line in cultObjects)
            { sb.Append(line.ToCsv() + '\n'); }
            // Создание потока.
            byte[] bytes = Encoding.UTF8.GetBytes(sb.ToString());
            MemoryStream stream = new MemoryStream(bytes);
            using (StreamWriter sw = new StreamWriter("result.csv"))
            {
                sw.WriteLine(sb.ToString());
            }
            return stream;
        }
    }
}
