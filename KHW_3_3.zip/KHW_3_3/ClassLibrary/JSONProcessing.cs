using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace ClassLibrary
{
    /// <summary>
    /// Класс для чтения и записи данных json-файла.
    /// </summary>
    public class JSONProcessing
    {
        /// <summary>
        /// Проверяеи, что у считанного файла в нужных полях стоят числовые значения.
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        private static bool CheckTypes(List<CultObject> result)
        {
            foreach (var value in result)
            {
                if (value.UsrchoNumber != "" && !long.TryParse(value.UsrchoNumber, out _)) { return false; }
                if (value.GlobalId != "" && !long.TryParse(value.GlobalId, out _)) { return false; }
            }
            return true;
        }


        /// <summary>
        /// Считывает файл.
        /// </summary>
        /// <param name="stream"></param>
        /// <returns>Список объектов обрабатываемого типа.</returns>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public static List<CultObject> Read(Stream stream)
        {
            try
            {
                // Итоговый список.
                List<CultObject> result = new() { };
                // Номер считываемой строки.
                int lineNumber = 0;
                string line;
                // перенос в начало файла.
                stream.Seek(0, SeekOrigin.Begin);
                // Считывание.
                using (StreamReader sr = new StreamReader(stream))
                {
                    string allText = sr.ReadToEnd().Replace('\n', ' ');
                    result = JsonSerializer.Deserialize<List<CultObject>>(allText);
                }
                // Если всего 1 объект, значит нет данных.
                if (result.Count <= 1) { throw new ArgumentOutOfRangeException(); }
                // проверка на соответствие полей первого объекта, хранязего русские названия полей.
                if (!(result[0].Aisid == "Идентификатор в АИС Мосгорнаследия" && result[0].UsrchoNumber == "Номер ЕГРОКН" && result[0].ObjectNameOnDoc == "Наименование объекта по документам"
                    && result[0].EnsembleNameOnDoc == "Наименование ансамбля по документам" && result[0].SecurityStatus == "Охранный статус" && result[0].Category == "Категория объекта"
                    && result[0].ObjectType == "Вид объекта недвижимости" && result[0].GlobalId == "global_id")) { throw new ArgumentOutOfRangeException(); }
                // Удаление первого объекта после проверки, т.к. не учавствует в редакции.
                result.RemoveAt(0);
                // Проверка на типы.
                if (!CheckTypes(result)) { throw new ArgumentOutOfRangeException(); }
                return result;
            }
            // Поймали исключение => некорректный формат.
            catch (ArgumentOutOfRangeException) { throw new ArgumentOutOfRangeException(); }
            catch (JsonException) { throw new ArgumentOutOfRangeException(); }
            catch (ArgumentNullException) { throw new ArgumentOutOfRangeException(); }
            catch (Exception) { throw new ArgumentOutOfRangeException(); }
        }


        /// <summary>
        /// Записывает обработанные данные в json-файл.
        /// </summary>
        /// <param name="cultObjects"></param>
        /// <returns></returns>
        public static Stream Write(List<CultObject> cultObjects)
        {
            // Первый объект с русскими названиями.
            CultObject cultObjectHeaders = new CultObject("Идентификатор в АИС Мосгорнаследия", "Номер ЕГРОКН", "Наименование объекта по документам", "Наименование ансамбля по документам",
                "Охранный статус", "Категория объекта", "Вид объекта недвижимости", "global_id");
            // Добавление для серализации.
            cultObjects.Insert(0, cultObjectHeaders);
            try
            {
                // Запись.
                string firstLine = JsonSerializer.Serialize(cultObjectHeaders, new JsonSerializerOptions { WriteIndented = true, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
                string text;
                using (StreamWriter sw = new StreamWriter("result.json"))
                {
                    text = JsonSerializer.Serialize(cultObjects, new JsonSerializerOptions { WriteIndented = true, Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
                    sw.Write(text);
                }
                // Создание потока.
                byte[] bytes = Encoding.UTF8.GetBytes(text);
                MemoryStream stream = new MemoryStream(bytes);
                return stream;
            }
            catch (Exception) { throw; }
            // Удалить первый объект с русскимим названиями.
            finally { cultObjects.RemoveAt(0); }
        }
    }
}
