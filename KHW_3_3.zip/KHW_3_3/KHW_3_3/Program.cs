﻿using ClassLibrary;
namespace KHW3_3
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            BotMain botMain = new BotMain();
            await botMain.Start();           
        }
    }
}